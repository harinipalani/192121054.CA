 def AND (a, b):
    if a == 1 and b == 1:
        return True
    else:
        return False
if _name=='main_':
    print(AND(1, 1))
    print(" | AND Truth Table | Result |")
    print(" A = False, B = False | A AND B =",AND(False,False)," | ")
    print(" A = False, B = True  | A AND B =",AND(False,True),"  | ")
    print(" A = True, B = False  | A AND B =",AND(True,False),"  | ")
    print(" A = True, B = True   | A AND B =",AND(True,True),"   | ")
    def NAND (a, b):
        if a == 1 and b == 1:
            return False
        else:
            return True
if _name=='main_':
    print(NAND(1, 0))
    print("*********")
    print(" | NAND Truth Table | Result |")
    print(" A = False, B = False | A AND B =",NAND(False,False)," | ")
    print(" A = False, B = True | A AND B =",NAND(False,True)," | ")
    print(" A = True, B = False | A AND B =",NAND(True,False)," | ")
    print(" A = True, B = True | A AND B =",NAND(True,True)," | ")

    def OR(a, b):
        if a == 1 or b ==1:
            return True
        else:
            return False
if _name=='main_':
    print(OR(0, 0))
    print("***********")
    print(" | OR Truth Table | Result |")
    print(" A = False, B = False | A OR B =",OR(False,False)," | ")
    print(" A = False, B = True | A OR B =",OR(False,True)," | ")
    print(" A = True, B = False | A OR B =",OR(True,False)," | ")
    print(" A = True, B = True | A OR B =",OR(True,True)," | ")
