#include <stdio.h>
int main() {
 float cachehit, cachemiss;
 float cachehitratio;
 printf("\n enter the total number of cache hits:");
 scanf("%d",&cachehit);
 printf("\n enter the number of cache misses:");
 scanf("%d",&cachemiss);
 cachehitratio=cachehit/(cachehit+cachemiss);
 printf("\n Cache Hit Ratio: %f",cachehitratio);
 printf("\n Cache Miss Ratio: %f",1-cachehitratio);
 return 0;
}


